# Spot the Composer

A browser-based daily guessing game for classical music fans.

## Play locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `.nojekyll`, and `README.md` to the repository root.
3. In **Settings → Pages**, choose the main branch and root folder.
4. Save, then open the Pages URL GitHub provides.

The game includes a daily challenge and unlimited practice mode. It uses a built-in composer list and does not require a server.
